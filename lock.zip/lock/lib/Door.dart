
import 'package:flutter/material.dart';

import 'package:lock/main.dart';


class Door extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new RaisedButton(
          child: Text("sign out"),
          onPressed: () => Navigator.of(context).pop(),
        ),
        leading: new Container(),
      ),
      body: new Container(),
    );
  }
}