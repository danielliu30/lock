import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';


class User{
  String userName;
  int userId;
  int accessLevel;
  User(String userName, int userId, int accessLevel){
      this.userName = userName;
      this.userId = userId;
      this.accessLevel = accessLevel;
  }
}