import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';

class Admin{
  final FirebaseAuth _fBAuth = FirebaseAuth.instance;
  FirebaseUser user = null;
  Future<String> createUser (String adminKey, String email, String pword) async{
    try{
      if(adminKey.toLowerCase() == "admin"){
        AuthResult result =  await _fBAuth.createUserWithEmailAndPassword(
            email: email.trim(), password: pword.trim());
        user = result.user;
      }
      return user.uid;
    }catch(e){
      if(e is PlatformException){
        print(e.details);
      }
    }
    return null;
  }

  void deleteUser(String email){

  }
  void signOut(){
  }

}